package com.qadevelopers.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import com.qadevelopers.utils.Constants;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class TestBase {

	protected WebDriver driver;
	ChromeOptions cop;
	
	@BeforeTest
	public void init() throws InterruptedException {
		ChromeOptions cp = setChromeOptions();
		System.setProperty("webdriver.chrome.driver", "./resources/driver/chromedriver.exe");
		driver = new ChromeDriver(cp);
		driver.get(Constants.url);
		Thread.sleep(2000);
	}
	
	@BeforeMethod
	public void beforeMethod(ITestResult res) {
		System.out.println("====== "+res.getMethod().getMethodName()+" Started=====");
	}
	
	@AfterMethod
	public void afterMethod(ITestResult res) {
		System.out.println("====== "+res.getMethod().getMethodName()+" Finished=====");
	}
	
	@AfterTest
	public void afterTest() {
		driver.quit();
	}
	
	/**
	 * This method is used to set the chrome options
	 * @return
	 */
	public ChromeOptions setChromeOptions() {
		cop = new ChromeOptions();
		cop.addArguments("start-maximized");
		cop.addArguments("disable-infobars");
		cop.addArguments("--disable-extensions");
		return cop;
	}
}
