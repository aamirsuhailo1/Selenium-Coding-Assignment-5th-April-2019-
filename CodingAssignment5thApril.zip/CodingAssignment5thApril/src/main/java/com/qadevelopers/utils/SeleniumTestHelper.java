package com.qadevelopers.utils;

import org.openqa.selenium.WebElement;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class SeleniumTestHelper {

	/**
	 * This method is used to enter text in textbox
	 * @param txtSearchBox
	 * @param city
	 */
	public static void enterTextInTextBox(WebElement txtSearchBox, String city) {
		
		try {
			if(txtSearchBox.isDisplayed()) {
				txtSearchBox.click();
				txtSearchBox.clear();
				txtSearchBox.sendKeys(city);
			}
			else {
				System.out.println("City search box is not displayed");
			}
		}catch(Exception e) {
			System.out.println("Cannot search city" + e.getMessage());
		}
		
	}

	/**
	 * This method is used to click on the button
	 * @param btnSearchBtutton
	 */
	public static void clickOnButton(WebElement btnSearchBtutton) {
		try {
			btnSearchBtutton.click();
		}catch(Exception e) {
			System.out.println("Cannot click on search button" + e);
		}
		
	}

	/**
	 * This method is used to click on the link
	 * @param PartialLink
	 * @return 
	 */
	public static boolean clickOnLink(WebElement PartialLink) {		
		try {
			PartialLink.click();
			return true;
		} catch (Exception e) {
			System.out.println("Cannot click on 5th property");
			return false;
		}
	}

}
