package com.qadevelopers.utils;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class Constants {
	
	public static String url = "https://www.zoopla.co.uk/";
	
}
