package com.qadevelopers.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qadevelopers.utils.SeleniumTestHelper;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class AgentDetailsPage {

	WebDriver driver;
	
	@FindBy(xpath="(//h4[@class='ui-agent__name'])[1]")
	public WebElement agentName;
	
	@FindBy(xpath="(//a[@data-track-category='listing details'])[3]")
	public WebElement agentNbr;
	
	
	public AgentDetailsPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	/**
	 * This method is used to click on the agent name
	 * @return
	 */
	public String clickOnAgentname() {
		String agntName = agentName.getText();
		SeleniumTestHelper.clickOnLink(agentName);
		return agntName;
	}

	public String[] getAgentNameAndNumber() {
		String[] ad = new String[2];
		String agntName = agentName.getText();
		String agntNum = agentNbr.getText();
		ad[0] = agntName;
		ad[1] = agntNum;
		return ad;
	}

	
}
