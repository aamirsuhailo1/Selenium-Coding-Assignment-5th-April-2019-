package com.qadevelopers.pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.qadevelopers.utils.SeleniumTestHelper;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class PropertyPricePage {

	WebDriver driver;
	
	@FindBy(xpath="//*[starts-with(@id,\"listing\")]/div/div[2]/a")
	public List<WebElement> lnkTxtpropertyPriceValues;
	
	
	
	public PropertyPricePage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	/**
	 * This method returns all the property price values
	 * @return
	 */
	public ArrayList<Double> getPropertyPrices() {
		ArrayList<Double> pp = new ArrayList<Double>();
		for(int i = 0; i < lnkTxtpropertyPriceValues.size();i++) {
			String txt = lnkTxtpropertyPriceValues.get(i).getText().replaceAll(",", "").split(" ")[0];
			double propPrice;
			try {
				propPrice = Double.parseDouble(txt.substring(1, (txt.length())-1));
				pp.add(propPrice);
			} catch (NumberFormatException e) {
				//Assert.assertTrue(false, "Property price value is not a number");
				System.out.println("Property price value "+txt+" is not a number");
			}
			
		}
		return pp;
	}
	
    /**
     * This method is used to click on the 5th property
     * @return
     */
	public boolean clickOn5thProperty() {
		return SeleniumTestHelper.clickOnLink(lnkTxtpropertyPriceValues.get(4));
	}

	
}
