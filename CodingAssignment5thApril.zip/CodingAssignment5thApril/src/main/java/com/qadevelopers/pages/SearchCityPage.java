package com.qadevelopers.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qadevelopers.utils.SeleniumTestHelper;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class SearchCityPage {

	WebDriver driver;
	
	@FindBy(id="search-input-location")
	public WebElement txtSearchBox;
	
	@FindBy(id="search-submit")
	public WebElement btnSearchBtutton;
	
	public SearchCityPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	
	/**
	 * This method searches city.
	 * @param city
	 * @return 
	 */
	public boolean searchCity(String city) {
		try {
			SeleniumTestHelper.enterTextInTextBox(txtSearchBox,city);
			System.out.println("Entered city name : "+city);
			SeleniumTestHelper.clickOnButton(btnSearchBtutton);
			System.out.println("Clicked on search button");
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
