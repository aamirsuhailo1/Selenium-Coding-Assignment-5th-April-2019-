package com.qadevelopers.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class AgentsPropertyDetailsPage {
	
	
	WebDriver driver;
	
	@FindBy(xpath="(//h1[@class=\"bottom-half\"]/b)[1]")
	public WebElement propertyAgentName;
	
	
	public AgentsPropertyDetailsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}

	
	/**
	 * this method is used to get the name and address of agent
	 * @return
	 */
	public String getAgentNameAndAddress() {
		return propertyAgentName.getText();
	}

}
