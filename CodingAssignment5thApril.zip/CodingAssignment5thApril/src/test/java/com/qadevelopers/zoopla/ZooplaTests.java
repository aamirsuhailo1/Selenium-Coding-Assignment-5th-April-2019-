
package com.qadevelopers.zoopla;

import java.util.ArrayList;
import java.util.Collections;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.qadevelopers.base.TestBase;
import com.qadevelopers.pages.AgentDetailsPage;
import com.qadevelopers.pages.AgentsPropertyDetailsPage;
import com.qadevelopers.pages.PropertyPricePage;
import com.qadevelopers.pages.SearchCityPage;

/**
 * @author Aamir Mohammed Suhail
 * @email  aamirsuhail01@yahoo.com
 */
public class ZooplaTests extends TestBase {
	
	public SearchCityPage searchCityPage ;
	public PropertyPricePage propertyPricePage;
	public AgentDetailsPage agentDetailsPage;
	public AgentsPropertyDetailsPage agentsPropertyDetailsPage;
	
	@BeforeClass
	public void beforeClass() {
		searchCityPage = new SearchCityPage(driver);
		propertyPricePage = new PropertyPricePage(driver);
		agentDetailsPage = new AgentDetailsPage(driver);
		agentsPropertyDetailsPage = new AgentsPropertyDetailsPage(driver);
	}
	
	/**
	 * This test method verifies whether we are able to search the city
	 */
	@Test
	public void searchCityTest() {
		Boolean searchStatus = searchCityPage.searchCity("London");
		Assert.assertTrue(searchStatus,"Unable to search the city");
		
	}

	
	/**
	 * This test method prints the property prices in descending order
	 */
	@Test(dependsOnMethods= {"searchCityTest"})
	public void printPropertyPricesTest() {
		ArrayList<Double> propPrices = propertyPricePage.getPropertyPrices();
		Collections.sort(propPrices, Collections.reverseOrder());
		System.out.println("Property Price Values in descending order are below : ");
		System.out.println(propPrices);
	}
	
	/**
	 * This test method is used to verify Agent's details
	 */
	@Test(dependsOnMethods= {"printPropertyPricesTest"})
	public void agentDetailsTest() {
		
		//click on 5th property
		Boolean clickStatus = propertyPricePage.clickOn5thProperty();
		Assert.assertTrue(clickStatus, "Unable to click on the 5th property");
		
		//print agentName and agentNumber on the console
		String[] ad =agentDetailsPage.getAgentNameAndNumber();
		System.out.println("Agent Name is : "+ad[0]);
		System.out.println("Agent Number is : "+ad[1]);
		
		//click on agent name link and get agent name
		String agentName =agentDetailsPage.clickOnAgentname();
		
		// get agent name from property details page
		String agentNameFromAgentPropDetailsPage = agentsPropertyDetailsPage.getAgentNameAndAddress();
		
		//verify agent names from both pages
		Assert.assertEquals(agentName, agentNameFromAgentPropDetailsPage);
		
		System.out.println("Agent and propertyDetails matched successfully");
	}
	
	
}
